# -*- coding: utf-8 -*-


__author__ = """Artem Golubin"""
__email__ = 'me@rushter.com'
__version__ = '0.2.3'
