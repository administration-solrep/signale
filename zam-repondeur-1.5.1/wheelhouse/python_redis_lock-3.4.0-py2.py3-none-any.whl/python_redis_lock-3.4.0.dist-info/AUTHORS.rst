
Authors
=======

* Ionel Cristian Mărieș - https://blog.ionelmc.ro
* Rob Terhaar - https://github.com/robbyt
* Corey Farwell - http://rwell.org
* Andrey Kobyshev - https://github.com/yokotoka
* Jardel Weyrich - https://twitter.com/jweyrich
* Victor Torres - https://github.com/victor-torres
* Andrew Pashkin - https://github.com/AndreiPashkin
* Tero Vuotila - https://github.com/tvuotila
* Joel Höner - https://github.com/athre0z
* Julie MacDonell - https://github.com/juliemacdonell
* Julien Heller - https://github.com/flux627
* Przemysław Suliga - https://github.com/suligap
