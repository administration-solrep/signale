# coding: utf-8
"""
Main entry point

See:

- https://docs.python.org/3/library/__main__.html

"""
from legipy.cli import cli

if __name__ == "__main__":
    cli()
