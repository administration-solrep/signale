#!/usr/bin/env python3
# encoding: utf-8

class Display(object):
    inline = 1
    block = 2
    none = 3

class WhiteSpace(object):
    normal = 1 # sequences of whitespace will collapse into a single one
    pre = 3    # sequences of whitespace will be preserved

class Line(object):
    '''
    Object used to represent a line
    '''
    __slots__ = ('margin_before', 'margin_after', 'prefix', 'suffix',
                 'content', 'list_bullet', 'padding', 'align', 'width')

    def __init__(self, align=None):
        self.margin_before = 0
        self.margin_after = 0
        self.prefix = ""
        self.suffix = ""
        self.content = ""
        self.list_bullet = ""
        self.padding = 0

    def extract_pre_text(self):
        pass

    def get_text(self):
        return ''.join(('\n' * self.margin_before,
                        ' ' * (self.padding - len(self.list_bullet)),
                        self.list_bullet,
                        self.prefix,
                        ' '.join(self.content.split()),
                        self.suffix,
                        '\n' * self.margin_after))

    def __str__(self):
        return "<Line: '{}'>".format(self.get_text().strip())
