# -*- coding: utf-8 -*-

from .candidats import donnelescandidats, generateur_donnelescandidats

# vim: set ts=4 sw=4 sts=4 et:
